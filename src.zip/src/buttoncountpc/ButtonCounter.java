package buttoncountpc;

import java.awt.Point;

import lejos.nxt.Button;
import lejos.nxt.LCD;
import lejos.nxt.Sound;
import lejos.util.Delay;

/**
 * counts number of presses of Leftand Rightbuttons <br>
 * Subtracts 1 from count if ENTER button is pressed simultaneously uses loop to
 * monitor buttons
 * 
 * @author Roger Glassey 9/10/07
 */
public class ButtonCounter {
	Point myPoint;

	public void count(String msg) 
	{
		myPoint = new Point();
		int x = 0;
		int y = 0;

		myPoint.setLocation(x, y);

		LCD.clear();
		System.out.println(msg);
		LCD.drawString(msg, 0, 0);
		boolean counting = true;

		/*LCD.drawString("English? (LEFT)", 0, 0);
		LCD.drawString("Espanol? (RIGHT)", 0, 1);
		int languageID = Button.waitForAnyPress();
		LCD.clear();
		
		if (languageID == 2) 
		{	
			LCD.drawString("Welcome!", 0, 0);
			Delay.msDelay(1000);
			LCD.clear();
		}

		else if (languageID == 4)
		{
			LCD.drawString("Bienvenidos!", 0, 1);
			Delay.msDelay(1000);
			LCD.clear();
		}*/

		while (counting) // sometime, make this false to exit the loop
		{
			LCD.drawString("Actions?", 0, 0);
			LCD.drawString("X=",10,0);
			LCD.drawString("Y=",10,1);
			LCD.drawInt(myPoint.x,12,0);
			LCD.drawInt(myPoint.y,12,1);
			
			int buttonID = Button.waitForAnyPress();
			if (buttonID > 0) 
			{
				if (buttonID == 2) // LEFT button pressed
				{
					myPoint.x++;
				}

				else if (buttonID == 3) 
				{
					myPoint.x--;
					
				}

				else if (buttonID == 4) 
				{
					myPoint.y++;
				}

				else if (buttonID == 5) 
				{
					myPoint.y--;
				}

				else if (buttonID == 8) 
				{
					/*if (languageID == 2) 
					{
						LCD.drawString("EXIT!", 1, 5);
						Delay.msDelay(3000);
						LCD.clear();
						counting = false;
					}

					else if (languageID == 4) 
					{
						LCD.drawString("SALIDA!", 1, 6);
						Delay.msDelay(3000);
						LCD.clear();
						counting = false;
					}*/
					
					LCD.drawString("EXIT!", 1, 5);
					Delay.msDelay(3000);
					LCD.clear();
					counting = false;

				}

				else 
				{
					LCD.drawString("Try again!", 0, 6);
					Sound.beep();
				}

			}

		}
	}
	
	public int getX()
	{
		return myPoint.x;
	}
	
	public int getY()
	{
		return myPoint.y;
	}
}
