package com.mydomain;

import java.awt.*;

import buttoncountpc.ButtonCounter;
import lejos.robotics.navigation.DifferentialPilot;
import lejos.util.Delay;
import lejos.nxt.*;

public class Milestone3 
{
	DifferentialPilot myPilot = new DifferentialPilot((float)(56/25.4),4.8f,Motor.A,Motor.B,false);
	LightSensor myLeftLightSensor = new LightSensor(SensorPort.S1);
	LightSensor myRightLightSensor = new LightSensor(SensorPort.S4);
	Tracker tracker = new Tracker(myPilot, myLeftLightSensor, myRightLightSensor);
	
	Point currentPoint = new Point();
	Point newPoint = new Point();
	Point oldPoint = new Point();
	
	void calibrate()
  	{
  		tracker.calibrate();
  	}
	
	void moveXdistance()
	{
		//Turn direction x-wise first
		if (oldPoint.y <= currentPoint.y)
		{
			if (newPoint.x > currentPoint.x)
			{
				myPilot.rotate(90);
				myPilot.travel(1);
			}
			else if (newPoint.x < currentPoint.x)
			{
				myPilot.rotate(-90);
				myPilot.travel(1);
			}
		}
		
		else if (oldPoint.y > currentPoint.y)
		{
			if (newPoint.x > currentPoint.x)
			{
				myPilot.rotate(-90);
				myPilot.travel(1);
			}
			else if (newPoint.x < currentPoint.x)
			{
				myPilot.rotate(90);
				myPilot.travel(1);
			}
		}
		//Go x distance
		int i=0;
		int x_distance = Math.abs(newPoint.x - currentPoint.x);
		
		while (i < x_distance)
		{
			int lval = tracker.lvalue(); //determine left sensor light value
  			int rval = tracker.rvalue(); //determine right sensor light value
  			tracker.trackLine(); //follow the blue tape		
  			 
  			//tells the robot what to do when it approaches the black tape
  			if (lval<0||rval<0)
  			{
  				Sound.beep();
  				i=i+1; //increase the "robot black tape approach count" by 1		
				//if the nth black tape approach is even, turn left
  				LCD.drawInt(currentPoint.x + i,12,0);
  				if (i == x_distance)
  				{
  					tracker.rotate(0);
  					break;
  				}
  				//else the robot just goes past the black tape and continues its journey
  				else 
  				{
  					while (true)
  					{
  						lval = tracker.lvalue();
  						rval = tracker.rvalue();
  						myPilot.steer(0);
  						
  						if (lval >= 0 && rval >= 0)
  						{
  							break;
  						}
  					}
  				}
  			}
		}
	}
	
	void moveYdistance()
	{
		//Turn direction y-wise
		if (newPoint.x <= currentPoint.x)
		{
			if (newPoint.y>currentPoint.y)
			{
				myPilot.rotate(90);
				myPilot.travel(1);
			}
			else if (newPoint.y<currentPoint.y)
			{
				myPilot.rotate(-90);
				myPilot.travel(1);
			}
		}
		else if (newPoint.x>currentPoint.x)
		{
			if (newPoint.y>currentPoint.y)
			{
				myPilot.rotate(-90);
				myPilot.travel(1);
			}
			else if (newPoint.y<currentPoint.y)
			{
				myPilot.rotate(90);
				myPilot.travel(1);
			}
		}
		
		int i=0;
		int y_distance = Math.abs(newPoint.y - currentPoint.y);
		
		while (i<y_distance)
		{
			int lval = tracker.lvalue(); //determine left sensor light value
  			int rval = tracker.rvalue(); //determine right sensor light value
  			tracker.trackLine(); //follow the blue tape		
  			 
  			//tells the robot what to do when it approaches the black tape
  			if (lval<0||rval<0)
  			{
  				Sound.beep();
  				i=i+1; //increase the "robot black tape approach count" by 1
  				LCD.drawInt(currentPoint.y + i,12,1);
  				if (i==y_distance)
  				{
  					tracker.rotate(0);
  					break;
  				}
  				
  				//else the robot just goes past the black tape and continues its journey
  				else 
  				{
  					while (true)
  					{
  						lval = tracker.lvalue();
  						rval = tracker.rvalue();
  						myPilot.steer(0);
  						
  						if (lval>=0&&rval>=0)
  						{
  							break;
  						}
  					}
  				}
  			}
		}
	}
	
	void StorePoints()
	{
		currentPoint = oldPoint;
		newPoint = currentPoint;
	}	

	public static void main(String[] args) 
	{
		Milestone3 myMS3 = new Milestone3();
		ButtonCounter myButtCount = new ButtonCounter();		
		myMS3.calibrate();
		
		LCD.drawString("Loading...", 0, 0);
		Delay.msDelay(1000);
		
		myMS3.oldPoint.setLocation(0,0);
		myMS3.currentPoint.setLocation(0,0);
		
		while(true)
		{	
			myButtCount.count("Let's Begin!");
		
			myMS3.newPoint.setLocation(myButtCount.getX(),myButtCount.getY());
		
			LCD.drawString("X=",10,0);
			LCD.drawString("Y=",10,1);
		
			LCD.drawInt(myMS3.newPoint.x,12,3);
			LCD.drawInt(myMS3.newPoint.y,12,4);	
		
			myMS3.moveXdistance();
			myMS3.moveYdistance();
			myMS3.StorePoints();
		}
	}

}
